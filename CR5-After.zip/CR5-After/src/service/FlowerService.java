package service;

import model.Inventory;
import model.Flower;
import model.Money;
import java.util.Scanner;

public class FlowerService {
    private Inventory inventory;

    public FlowerService(Inventory inventory) {
        this.inventory = inventory;
    }

    public void addFlowerToInventory() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan nama bunga: ");
        String name = scanner.nextLine();
        System.out.print("Masukkan harga bunga: ");
        double priceAmount = scanner.nextDouble();
        System.out.print("Masukkan jumlah bunga: ");
        int quantity = scanner.nextInt();

        Money price = new Money(priceAmount);
        Flower flower = new Flower(name, price, quantity);
        inventory.addFlower(flower);
        System.out.println("Bunga berhasil ditambahkan!");
    }

    public void displayInventory() {
        inventory.displayInventory();
    }

    public void reduceFlowerQuantity(String flowerName, int quantity) {
        Flower flower = inventory.findFlowerByName(flowerName);
        if (flower != null) {
            flower.reduceQuantity(quantity);
            System.out.println("Jumlah bunga berhasil diperbarui!");
        } else {
            System.out.println("Bunga tidak ditemukan.");
        }
    }
}
