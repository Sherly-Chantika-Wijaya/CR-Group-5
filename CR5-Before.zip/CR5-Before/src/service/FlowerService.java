package service;

import model.Inventory;
import model.Flower;
import java.util.Scanner;

public class FlowerService {
    private Inventory inventory;

    public FlowerService(Inventory inventory) {
        this.inventory = inventory;
    }

    // Menambah bunga ke dalam inventory
    public void addFlowerToInventory() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Tambah bunga ke inventory:");
        System.out.print("Masukkan nama bunga: ");
        String name = scanner.nextLine();
        System.out.print("Masukkan harga bunga: ");
        double price = scanner.nextDouble();
        System.out.print("Masukkan jumlah bunga: ");
        int quantity = scanner.nextInt();

        Flower flower = new Flower(name, price, quantity);
        inventory.addFlower(flower); // Menambahkan bunga ke inventory
        System.out.println("Bunga berhasil ditambahkan!");
    }

    // Menampilkan daftar bunga di inventory
    public void displayInventory() {
        inventory.displayInventory(); // Menampilkan daftar bunga
    }

    // Memperbarui jumlah bunga berdasarkan pemesanan
    public void reduceFlowerQuantity(String flowerName, int quantity) {
        Flower flower = inventory.findFlowerByName(flowerName);
        if (flower != null) {
            flower.reduceQuantity(quantity); // Mengurangi jumlah bunga yang dipesan
            System.out.println("Jumlah bunga " + flowerName + " berhasil diperbarui!");
        } else {
            System.out.println("Bunga tidak ditemukan di inventory.");
        }
    }
}
