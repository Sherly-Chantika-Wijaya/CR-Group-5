package service;

import model.Inventory;

public class InventoryService {
    private Inventory inventory;

    public InventoryService(Inventory inventory) {
        this.inventory = inventory;
    }

    // Menampilkan inventory
    public void showInventory() {
        inventory.displayInventory(); // Menampilkan semua bunga
    }
}
