package main;

import model.Inventory;
import service.FlowerService;
import service.InventoryService;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory(); // Membuat objek inventory
        FlowerService flowerService = new FlowerService(inventory); // Layanan bunga
        InventoryService inventoryService = new InventoryService(inventory); // Layanan inventory
        Scanner scanner = new Scanner(System.in);

        while(true) {
            System.out.println("=== Toko Bunga ===");
            System.out.println("1. Tambah bunga");
            System.out.println("2. Lihat inventory");
            System.out.println("3. Kurangi jumlah bunga");
            System.out.println("4. Keluar");
            System.out.print("Pilih menu: ");
            int choice = scanner.nextInt();

            if(choice == 1) {
                flowerService.addFlowerToInventory();
            } else if(choice == 2) {
                inventoryService.showInventory();
            } else if(choice == 3) {
                scanner.nextLine(); // Flush the newline
                System.out.print("Masukkan nama bunga: ");
                String flowerName = scanner.nextLine();
                System.out.print("Masukkan jumlah bunga yang ingin dikurangi: ");
                int quantity = scanner.nextInt();
                flowerService.reduceFlowerQuantity(flowerName, quantity);
            } else if(choice == 4) {
                break;
            } else {
                System.out.println("Pilihan tidak valid.");
            }
        }
    }
}
