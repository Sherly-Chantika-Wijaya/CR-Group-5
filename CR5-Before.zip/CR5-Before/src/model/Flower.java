package model;

public class Flower {
    private String name;
    private double price; // harga bunga dalam satuan rupiah
    private int quantity; // jumlah bunga yang tersedia

    // Constructor untuk membuat objek bunga
    public Flower(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // Mendapatkan nama bunga
    public String getName() {
        return name; // Nama bunga
    }

    // Mendapatkan harga bunga
    public double getPrice() {
        return price; // Harga bunga per unit
    }

    // Mendapatkan jumlah bunga
    public int getQuantity() {
        return quantity; // Jumlah bunga yang ada di inventory
    }

    // Mengurangi jumlah bunga
    public void reduceQuantity(int amount) {
        // Mungkin perlu verifikasi sebelum mengurangi
        this.quantity -= amount; // Mengurangi jumlah bunga
    }
}
