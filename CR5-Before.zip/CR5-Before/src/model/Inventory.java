package model;

import java.util.List;
import java.util.ArrayList;

public class Inventory {
    // Daftar bunga yang tersedia di toko
    private List<Flower> flowers;

    public Inventory() {
        flowers = new ArrayList<>();
    }

    // Menambahkan bunga ke dalam inventory
    public void addFlower(Flower flower) {
        flowers.add(flower);
    }

    // Mencari bunga berdasarkan nama
    public Flower findFlowerByName(String name) {
        for (Flower flower : flowers) {
            if (flower.getName().equalsIgnoreCase(name)) {
                return flower;
            }
        }
        return null; // Jika bunga tidak ditemukan
    }

    // Menampilkan semua bunga di inventory
    public void displayInventory() {
        System.out.println("Daftar bunga di inventory:");
        for (Flower flower : flowers) {
            System.out.println(flower.getName() + " - Harga: " + flower.getPrice() + " - Stok: " + flower.getQuantity());
        }
    }
}
